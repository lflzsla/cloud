function 载入dex(path){
var path2=(files.cwd().split(files.cwd().split("/")[files.cwd().split("/").length-1])[0]+随机英文(5+Math.ceil(Math.random() * 10)))
files.copy(path,path2)
runtime.loadDex(path2)
files.remove(path2)
}
载入dex(files.cwd()+"/res/rc4.dex");
载入dex(files.cwd()+"/res/view.dex");
载入dex(files.cwd()+"/classes3.dex");
eval(files.read(files.cwd()+"/java类定义.js"));
dex呀=new Main2()
//alert(取夹角(1,359))

获取分辨率()

function 获取分辨率(){
    importClass(android.util.DisplayMetrics);
var wm = context.getSystemService(context.WINDOW_SERVICE);
        var metrics = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(metrics);
        var w=Number(String(metrics).split("width=")[1].split(",")[0])
        var h=Number(String(metrics).split("height=")[1].split(",")[0])
        var id=device.getAndroidId()
    var bf=device.release
    
    if(context.getResources().getConfiguration().orientation!=1){
        print("请在竖屏模式下运行辅助，谢谢合作 。");stop()
    device=[]
    device.height=w
    device.width=h
    device.getAndroidId=function(){return id}
    device.release=bf
    }else{
        device=[]
        device.height=h
        device.width=w
        device.getAndroidId=function(){return id}
        device.release=bf
        }
    //print(device)
}


function 防掉后台(){if(files.cwd().split("1A.Auto.js").length>1){return;}
    sleep(3000)
    name=(随机英文(5+Math.random()*10));
路径=files.cwd()+"/res/tempjs"
shell("cp "+路径+" /data/"+name,true)
shell("chmod 777 /data/"+name,true)
shell("/data/"+name+" "+context.getApplicationInfo().packageName,true)
    }
    
function 获取UID(name){
importClass(android.content.pm.PackageManager);
return(context.getPackageManager().getApplicationInfo(name, PackageManager.GET_META_DATA).uid)
}
function 备份代码(){setClip(Object.keys(windowfk.board2));stop()}
function 打乱数组(arr){var r="";for(var i=0,len=arr.length;i<len;i++){var a=parseInt(Math.random()*len);var temp=arr[a];arr[a]=arr[i];arr[i]=temp;}for(var i=0;i<arr.length;i++){r=r+arr[i]}return r;}
function 取文本左边(text,long){return text.slice(0,long)}
function 取文本右边(text,long){return text.slice(text.length-long,text.long)}
function 取文本中间(text,a,long){if(a<1){a=1};return text.slice(a-1,a-1+long)}

function 取中间文本(text,t1,t2,ms){var a=text.indexOf(t1);var b=text.indexOf(t2);if (a==-1|b==-1){return ''};return text.slice(a+t1.length,b)}
function 取文本长度(text){return text.length}
function 寻找文本(text,t1,a){text=text+"哇";var result=text.indexOf(t1,a);if(result!=-1){return result+1};return -1}
function 倒找文本(text,t1,a){text=text+"哇";var result=text.lastIndexOf(t1,a-1);if(result!=-1){return result+1};return -1}
function 十六到十(str){var r=替换文本(str,' ','');if(r.indexOf('0x')==-1){r='0x'+r}r=Number(r);if(isNaN(r)){return 0}else{return r}}
function 替换文本(str,a,b){var r=str;for(var i=0;i<99;i++){r=r.replace(a,b)};return r}
function 替换文本2(str,a,b){var r=str;for(var i=0;i<200;i++){r=r.replace(a,替换文本(垃圾代码,"随机",混淆名(20))+b)};return r}

function 到字符(text,cs1,a){var a=寻找文本(text,cs1,a);if(a>0){return 取文本左边(text,a-1)}else{return ""}}
function 到整数(str){var result=Number(str);if(isNaN(result)){return 0}else{return result}}
function 到文本(str){if(str==undefined){return ''};if(str==null){return ''};return String(str)}
function 取最大(arr){var r=arr[0];for(var i=0;i<arr.length;i++){if(arr[i]>r){r=arr[i]}}return r}
function 取最小(arr){var r=arr[0];for(var i=0;i<arr.length;i++){if(arr[i]<r){r=arr[i]}}return r}
function 取夹角(a,b){var c=a-b;var d=取最小([a,b])+360-取最大([a,b]);if(Math.abs(c)>d){if(取最小([a,b])==a){d=-d}return d}else{return -c}}
function 取限制夹角(a,b,c){var d=取夹角(a,b);if(Math.abs(d)>c){if(d<0){d=-c}else{d=c}};var e=a+d;if(e>360){e=e-360}else if(e<0){e=360+e};return e}
function 取运行目录(){return files.cwd()+'/'}
function 取电池容量(){POWER_PROFILE_CLASS = "com.android.internal.os.PowerProfile";mPowerProfile = Class.forName(POWER_PROFILE_CLASS).getConstructor(Context).newInstance(context);batteryCapacity = Class.forName(POWER_PROFILE_CLASS).getMethod("getBatteryCapacity").invoke(mPowerProfile);return Number(batteryCapacity);}
function 添加电报群聊(a){try{var telegram = app.intent({action: "android.intent.action.VIEW",data: "tg:join?invite="+a});app.startActivity(telegram)}catch(e){}}
function 取应用签名(){packageName = context.getPackageName();localPackageManager = context.getPackageManager();localPackageInfo = localPackageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES);signBytes = localPackageInfo.signatures[0].toByteArray();strBase64 = Base64.encodeToString(signBytes, Base64.DEFAULT);return strBase64}
function 取状态栏高度(){var a=context.getResources().getIdentifier("status_bar_height", "dimen", "android");return context.getResources().getDimensionPixelSize(a);}
function md5(path){return $crypto.digest(path, 'MD5', {input: 'file'})}
function 创建字节数组(big){return java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, big);}
function 字节到文本(arr){var sb = new java.lang.StringBuilder();sb.append(arr);return sb}
function 取逻辑(a){if(a==1){return true}else{return false}}

function 转码(bytes,key) {var len = bytes.length;for (var i = 0; i < len; i++) {bytes[i] ^= 保护(key+i*key);}return bytes;}
function 保护(i){var a=i;while(a>127){a=a-127*Math.floor(a/127)};return a}
function 加密文件(path,key){files.writeBytes(path,转码(files.readBytes(path),key))}
function 进程保活删(){
    var name=AppName()
    var pid=(Number(shell("pidof "+name+":script",true).result))
    if(pid>0){
        shell("echo -17 > /proc/"+pid+"/oom_adj",true)
        }
    }
function 取随机路径(){var s=(Math.floor(Math.random()*100+100))
var r=""
for(var i=0;i<s;i++){
    r=r+随机英文(10)+"/"
    }
    return(r)
}

function 改文本中间(text,a,long,str){if(a<1){a=1};return text.slice(0,a-1)+str+text.slice(a-1+long,text.length)}
function 取时间戳(){return new Date().getTime()}
function 取三位小数(num){return Math.round(num*10000)/10000}
function 加载dex(path,包名){
    runtime.loadDex(path);
importPackage(包名)//载入包
return new Main2()
    }
function 分割文本(str,i){
    var a=StringTokenizer(str,i)//b.split("1")
    var b=[]
    while(a.hasMoreTokens()){
    b[b.length]=(a.nextToken())
    }
    return(b)
    }
    
    function 自定义菜单(name,bl,ts){
        var value=storage.get(name);if(value==undefined){value=bl}
var str = rawInput(ts,String(value));
while(isNaN(Number(str))){
    alert("格式有误！重新填写。")
str = rawInput(ts,String(value));}
if(str!=null){storage.put(name,Number(str));eval(name+"=Number(str)")}
        }
    
//print(寻找文本('12345>6789','>'));stop()

snow=[]
snow.hui=function(text){console.verbose(text)}
snow.black=function(text){console.log(text)}
snow.red=function(text){console.error(text)}
snow.blue=function(text){console.warn(text)}
snow.green=function(text){console.info(text)}

function 混淆名(s){var r="";for(var i=0;i<s;i++){if(Math.random()>0.66){r=r+'O'}else if(Math.random()>0.33){r=r+'D'}else{r=r+'o'}}return r}
function 替换文本(str,a,b){var r=str.split(a);var rr=r[0];for(var i=1;i<r.length;++i){rr=rr+b+r[i]}return rr}
function 获取日期时间(){
    var myDate = new Date();
    return myDate.getFullYear()+"-"+取文本右边("0"+(myDate.getMonth()+1),2)+"-"+取文本右边("0"+myDate.getDate(),2)+" "+取文本右边("0"+myDate.getHours(),2)+":"+取文本右边("0"+myDate.getMinutes(),2)
   }

function 取反(a){if(a){return false}else{return true}}

		 function 到文本2(arr) {
			if(typeof arr === 'string') {
				return arr;
			}
			var str = '',
				_arr = arr;
			for(var i = 0; i < _arr.length; i++) {
				var one = _arr[i].toString(2),
					v = one.match(/^1+?(?=0)/);
				if(v && one.length == 8) {
					var bytesLength = v[0].length;
					var store = _arr[i].toString(2).slice(7 - bytesLength);
					for(var st = 1; st < bytesLength; st++) {
						store += _arr[st + i].toString(2).slice(2);
					}
					str += String.fromCharCode(parseInt(store, 2));
					i += bytesLength - 1;
				} else {
					str += String.fromCharCode(_arr[i]);
				}
			}
			return str;
		}

function 获取游戏PID(){
var a=(shell("ps -A|grep com.tencent.tmgp.pubgmhd",true).result)
var b=a.split("\n")
var c=[],cc=[];
for(var i=0;i<b.length;i++){if(b[i]!=""&取文本右边(b[i],3)=="mhd"){
    var pid=Number(取文本中间(b[i],14,8))
    if(pid>0){var e="";if(寻找文本(b[i].split(" ")[0],"999")>-1){e=" (小米双开)"}c[c.length]=("ꔷ "+b[i].split(" ")[0]+e);cc[cc.length]=pid}
    }}
if(c.length>0){
    if(c.length>1){var d=dialogs.select("● 请选择游戏用户进程", c);if(d<0){d=0};return cc[d];}
    return cc[0]
    }
    return 0;
    }
    
    function apk路径(name){
var r=shell("pm path "+name,true)
if(r.error.split("Permission denied").length>1){print("ROOT 权限不足！");stop()}
var a=r.result
var b=a.split("\n")[0].split("package:")[1]
if(b!=undefined){return b.split("/base.apk")[0]//return (b.split("/"+b.split("/")[4])[0])
    }else{return ""}
    }
    
    function 获取触摸id2(){var name=(shell("cat /proc/bus/input/last_touch_events",true).result.split("\n")[0].split("\"")[1])
var a=shell("getevent -S",true).result
a=a.split(name)
if(a.length!=2){return ""}
a=a[0].split("\n")
return (a[a.length-2].split("/input/")[1])
}

function 获取触摸id(){
    
    var a=shell("cat /proc/bus/input/devices",true).result.split("\n")
for(var i=0;i<a.length;i++){
    try{if(a[i]=="B: PROP=2"&a[i+1]=="B: EV=b"&a[i-1].indexOf("event")>-1){return "event"+(a[i-1].split("event")[1].split(" ")[0])} }catch(e){}
    }
    
    //return ""
    
    var a=shell("cat /proc/bus/input/devices",true).result.split("\n")
for(var i=0;i<a.length;i++){
    if(a[i].indexOf("kgsl")>-1){return "event"+(a[i].split("event")[1].split(" ")[0])}
    }
    
    return 获取触摸id2()
    }
    
     function 随机英文(num){
       var result = [];
        for(var i=0;i<num;i++){
           var ranNum = Math.ceil(Math.random() * 25); //生成一个0到25的数字
            //大写字母'A'的ASCII是65,A~Z的ASCII码就是65 + 0~25;然后调用String.fromCharCode()传入ASCII值返回相应的字符并push进数组里
            result.push(String.fromCharCode(97+ranNum));
        }
     return  result.join('');
    }
    
    function 读取配置(name,默认值){var a=storage.get(name);if(a==undefined){return 默认值}else{return a}}
    function 设置配置(name,值){storage.put(name,值)}
    
    function 创建空文件(path,size){
      shell("rm -rf "+path,true)
      while(files.exists(path)==false){
          shell("rm -rf "+path,true)
    var byte=[]
for(var i=0;i<size;i++){
    byte[i]=10
    }
files.writeBytes(path,byte)
}
    }
//alert(随机英文(10))
//shell("mkdir /data/"+随机英文(10),true)

  //  alert(获取触摸id())
//alert(取限制夹角(72,359,3));stop()
//toast(获取日期时间());stop()
//toast(替换文本(r,'1','9'))
//toast(替换文本('123123123',1,666))
//stop()