try{
  //  windoww5.close()
 //   windoww6.close()
    windoww7.close()
    }catch(e){}
可以移动=true
var window = floaty.window(
    <frame>
        <button id="action" text="自动1" w="40" h="40" bg="#77ffffff"/>
    </frame>
);

//setInterval(()=>{}, 1000);

var execution = null;
var x = 0, y = 0;
var windowX, windowY;
var downTime;
window.action.setOnTouchListener(function(view, event){switch(event.getAction()){case event.ACTION_DOWN:
            x = event.getRawX();
            y = event.getRawY();
            windowX = window.getX();
            windowY = window.getY();
            downTime = new Date().getTime();
            return true;
        case event.ACTION_MOVE:
            if(new Date().getTime() - downTime > 1){
                var aa=window.getX()+50
                var bb=window.getY()+50
                //window.action.setText(String(Math.floor(aa+50))+"x"+String(Math.floor(bb+50)))
                window.setPosition(windowX + (event.getRawX() - x),windowY + (event.getRawY() - y));
            }
            return true;
        case event.ACTION_UP:
            //手指弹起时如果偏移很小则判断为点击
            if(Math.abs(event.getRawY() - y) < 5 && Math.abs(event.getRawX() - x) < 5){
                //window.close()
            }
            return true;
    }
    return true;
});


var window2 = floaty.window(
    <frame>
        <button id="action" text="自动2" w="40" h="40" bg="#77ffffff"/>
    </frame>
);

//setInterval(()=>{}, 1000);

var execution = null;
var x = 0, y = 0;
var window2X, window2Y;
var downTime;
window2.action.setOnTouchListener(function(view, event){switch(event.getAction()){case event.ACTION_DOWN:
            x = event.getRawX();
            y = event.getRawY();
            window2X = window2.getX();
            window2Y = window2.getY();
            downTime = new Date().getTime();
            return true;
        case event.ACTION_MOVE:
            if(new Date().getTime() - downTime > 1){
                var aa=window2.getX()+50
                var bb=window2.getY()+50
                //window2.action.setText(String(Math.floor(aa+50))+"x"+String(Math.floor(bb+50)))
                window2.setPosition(window2X + (event.getRawX() - x),window2Y + (event.getRawY() - y));
            }
            return true;
        case event.ACTION_UP:
            //手指弹起时如果偏移很小则判断为点击
            if(Math.abs(event.getRawY() - y) < 5 && Math.abs(event.getRawX() - x) < 5){
                //window2.close()
            }
            return true;
    }
    return true;
});


var window3 = floaty.window(
    <frame>
        <button id="action" text="应用设置" w="80" h="40" bg="#77ffffff"/>
    </frame>
);

//setInterval(()=>{}, 1000);

var execution = null;
var x = 0, y = 0;
var window3X, window3Y;
var downTime;
window3.action.setOnTouchListener(function(view, event){switch(event.getAction()){case event.ACTION_DOWN:
            x = event.getRawX();
            y = event.getRawY();
            window3X = window3.getX();
            window3Y = window3.getY();
            downTime = new Date().getTime();
            return true;
        case event.ACTION_MOVE:
            if(new Date().getTime() - downTime > 1){
                var aa=window3.getX()+50
                var bb=window3.getY()+50
                //window3.action.setText(String(Math.floor(aa+50))+"x"+String(Math.floor(bb+50)))
                //window3.setPosition(window3X + (event.getRawX() - x),window3Y + (event.getRawY() - y));
            }
            return true;
        case event.ACTION_UP:
            //手指弹起时如果偏移很小则判断为点击
            if(Math.abs(event.getRawY() - y) < 5 && Math.abs(event.getRawX() - x) < 5){
                //window3.close()
                var r=(window.getX()+50-lhp)+" "+(window.getY()+50)+" "+(window2.getX()+50-lhp)+" "+(window2.getY()+50)+" "+(window4.getX()+50-lhp)+" "+(window4.getY()+50)+" "
            window.close()
            window2.close()
            window3.close()
            window4.close()
            可以移动=false
            触摸位置=r
            storage.put("触摸位置",触摸位置)
            alert(触摸位置)
            print(触摸位置)
            hook()
            }
            return true;
    }
    return true;
});

var window4 = floaty.window(
    <frame>
        <button id="action" text="自动3" w="40" h="40" bg="#77ffffff"/>
    </frame>
);

//setInterval(()=>{}, 1000);

var execution = null;
var x = 0, y = 0;
var window4X, window4Y;
var downTime;
window4.action.setOnTouchListener(function(view, event){switch(event.getAction()){case event.ACTION_DOWN:
            x = event.getRawX();
            y = event.getRawY();
            window4X = window4.getX();
            window4Y = window4.getY();
            downTime = new Date().getTime();
            return true;
        case event.ACTION_MOVE:
            if(new Date().getTime() - downTime > 1){
                var aa=window4.getX()+50
                var bb=window4.getY()+50
                //window4.action.setText(String(Math.floor(aa+50))+"x"+String(Math.floor(bb+50)))
                window4.setPosition(window4X + (event.getRawX() - x),window4Y + (event.getRawY() - y));
            }
            return true;
        case event.ACTION_UP:
            //手指弹起时如果偏移很小则判断为点击
            if(Math.abs(event.getRawY() - y) < 5 && Math.abs(event.getRawX() - x) < 5){
                //window4.close()
            }
            return true;
    }
    return true;
});



window.setPosition(463,600)
window2.setPosition(563,450)
window4.setPosition(663,300)
window3.setPosition(60,100)


windoww7 = floaty.window(
    <frame>
        <button id="action" text="百里" w="40" h="40" bg="#77ffffff"/>
    </frame>
);

//setInterval(()=>{}, 1000);

var execution = null;
var x = 0, y = 0;
var windoww7X, windoww7Y;
var downTime;
windoww7.action.setOnTouchListener(function(view, event){switch(event.getAction()){case event.ACTION_DOWN:
            x = event.getRawX();
            y = event.getRawY();
            windoww7X = windoww7.getX();
            windoww7Y = windoww7.getY();
            downTime = new Date().getTime();
            return true;
        case event.ACTION_MOVE:
            if(可以移动&new Date().getTime() - downTime > 1){
                var aa=windoww7.getX()+50
                var bb=windoww7.getY()+50
                //windoww7.action.setText(String(Math.floor(aa+50))+"x"+String(Math.floor(bb+50)))
                windoww7.setPosition(windoww7X + (event.getRawX() - x),windoww7Y + (event.getRawY() - y));
            }
            return true;
        case event.ACTION_UP:
            //手指弹起时如果偏移很小则判断为点击
            if(可以移动==false){zimiaoz.seek(0);zimiaoz.writeBytes("2 ")}
            if(Math.abs(event.getRawY() - y) < 5 && Math.abs(event.getRawX() - x) < 5){
                //windoww7.close()
            }
            return true;
    }
    return true;
});

windoww7.setPosition(360,100)
//windoww6.setPosition(560,100)
//windoww7.setPosition(760,100)


