importPackage(com.kk);
importClass(com.xuehua.test.RC4);
importClass(android.graphics.RectF);
importClass(java.io.RandomAccessFile)
importClass(android.graphics.PorterDuff);
importClass(android.graphics.Region)
importClass(android.widget.Button);
importClass(com.autojs.huizhi.mView)
//importClass(com.autojs.huizhi.mGlView)

importClass(android.graphics.BitmapFactory);
importClass(java.io.FileInputStream);
importClass(java.net.NetworkInterface)
importClass(java.util.Collections)
importClass(java.util.Enumeration)
importClass(java.lang.Integer);
importClass(android.text.TextUtils);
importClass(android.net.Proxy);
importClass(android.os.Build);
importClass(java.lang.System);
importClass(android.net.ConnectivityManager);
importClass(android.content.Context);
importClass(android.util.Base64);
importClass(android.content.pm.PackageManager);
importClass(java.io.FileOutputStream);
importClass(java.io.File);
importClass(java.io.IOException);
importClass(java.io.RandomAccessFile);
importClass(java.nio.ByteBuffer);
importClass(java.nio.MappedByteBuffer);
importClass(java.nio.channels.FileChannel);
importClass(java.nio.channels.FileLock);
importClass(android.content.Context);
importClass(java.lang.Class);
importClass(java.util.StringTokenizer);

//全局变量
人物基址=""
矩阵基址=""

最近=[]
预瞄=[]
计时=new Date().getTime()
截取时间=16//ms
aj=0
坐标=[]
坐标[0]={x:0,y:0,z:0}
坐标[1]={x:0,y:0,z:0}
坐标[2]={x:0,y:0,z:0}
//倍率=1
锁定目标地址=""
视角=[]

哈哈=new Date().getTime()