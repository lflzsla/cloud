"ui";
var snow = require('snow.js');
var storage = storages.create("ABC");
// 设置自定义主题
ui.statusBarColor("#000000")
    ui.layout(
        <vertical>
            <appbar background="#708090">
                <toolbar id="toolbar" title="[雪花] 和平精英雷达绘制" />
            </appbar>
            <vertical h="auto" align="center" margin="10 30">
        <img src="file://res/1.png" h='*' borderWidth="0dp" borderColor="#202020"/>
        </vertical>
                 
        <vertical h="auto" align="center" margin="10 10">
          <linear>
             <input id="name" w="*" h="40" hint="请将卡密粘贴至此处..." text=""/>
          </linear>
          
          <linear gravity="center">
             <button id="login" w="280" text="登录"/>
          </linear>
          <linear gravity="center">
             <button id="login2" w="280" text="》》》   打开卡密购买链接   《《《"/>
          </linear>
        </vertical>
         </vertical>
    );
      ui.login.on("click", () => {
          //if(ui.name.text()!='jujiu'+String(756947243003)){
       if(Login(ui.name.text())){storage.put("卡密",ui.name.text());toast("登录成功√");stop()
           //var file = open("km.log", "w");file.write(ui.name.text());file.close();
           //engines.execScriptFile("main.js");stop();
           }//}//else{var file = open("km.log", "w");file.write(ui.name.text());file.close();}//engines.execScriptFile("main.js");stop()}
    });
    ui.login2.on("click", () => {var 发卡网="http://t.cn/AijxfaIP";app.openUrl(发卡网);setClip(发卡网);toast("已为你复制购买链接，如自动打开浏览器失败请手动粘贴网址进行访问。")
    });
    
    function Login(cs1){
var imei=device.getIMEI()
if(imei==null){imei='123'}
var url = "http://w.eydata.net/43a32eeb6a82ef2c";
var res = http.post(url, {"SingleCode": cs1,"Ver": '1.0',"Mac":imei});
var html = res.body.string();
if(html.length==32){print(post("http://w.eydata.net/0dee1ac8f16f7778",{"StatusCode":html,"UserName":ui.name.text(),"UserData":999}));print(post("http://w.eydata.net/869b475b7702b9a2",{"StatusCode":html,"UserName":ui.name.text(),"UserData":789}));return true}else{snow.yyresult(html);return false}
}

function post(url,data){
    var res = http.post(url,data);
return res.body.string();
    }

