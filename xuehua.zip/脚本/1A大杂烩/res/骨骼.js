eval(files.read(files.cwd()+"/模块.js"));
/*
a=files.read("/storage/emulated/0/tencent/QQfile_recv/骨骼.cpp").split("\n")
b=""
for(i=0;i<a.length;i++){
     if(寻找文本(a[i],"MatrixValue",0)==-1){b=b+a[i]+"\n"}
    }
files.write("/storage/emulated/0/tencent/QQfile_recv/骨骼2.cpp",b)
*/
a=files.read("/storage/emulated/0/tencent/QQfile_recv/骨骼.cpp")//.split("\n")
b=""
for(i=0;i<15;i++){
b=b+替换文本(a,"1",i)+"\n"}
files.write("/storage/emulated/0/tencent/QQfile_recv/骨骼2.cpp",b)

stop()